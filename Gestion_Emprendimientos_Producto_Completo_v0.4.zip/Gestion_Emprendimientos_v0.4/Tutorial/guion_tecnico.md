# Gestión para emprendimientos · Tutorial de 3 minutos

El MP4 es una base de video de 3:00, 1920×1080, con capturas reales de la aplicación, acercamientos, resaltados y subtítulos incorporados. No tiene voz ni música. Las imágenes no son una interfaz inventada ni una grabación continua de los clics: son pantallas capturadas durante una demostración real y montadas en secuencia.

## Ejemplo definido

- Producto: Termo de acero, TER-001, categoría Termos. Precio UYU 500, stock inicial 20, mínimo 5.
- Ana · Cliente de ejemplo: 2 termos, UYU 1.000. Se entrega y se registra un cobro manual de UYU 1.000.
- Bruno · Cliente de ejemplo: otro pedido de 3 termos, UYU 1.500. Cliente ausente; se registra No entregado y después el retorno físico completo. Sin cobro.
- Transporte: Transporte Demo, matrícula DEMO-01, Conductor de prueba, documento Otro: DEMO-001.
- Teléfonos ficticios: 000000101 y 000000102. Direcciones de ejemplo 123 y 456.

## Stock paso a paso

| Momento | En depósito | Reservado | Disponible | En reparto |
|---|---:|---:|---:|---:|
| Producto recién creado | 20 | 0 | 20 | 0 |
| Pedido de Ana guardado | 20 | 2 | 18 | 0 |
| Ana despachado | 18 | 0 | 18 | 2 |
| Ana entregado | 18 | 0 | 18 | 0 |
| Pedido de Bruno guardado | 18 | 3 | 15 | 0 |
| Bruno despachado | 15 | 0 | 15 | 3 |
| Bruno no entregado | 15 | 0 | 15 | 3 |
| Retorno físico de Bruno confirmado | 18 | 0 | 18 | 0 |

Resultado: una entrega por UYU 1.000, UYU 1.000 cobrados, saldo por cobrar cero. Los pedidos devueltos no integran el saldo activo.

## Cómo terminar la versión con voz

1. Importá Gestion_Emprendimientos_Tutorial_3min_Sin_Voz.mp4 en tu editor.
2. Grabá o generá la locución de locucion.txt en español rioplatense, respetando las entradas y salidas. Son aproximadamente 3 minutos a ritmo conversacional.
3. Agregá el audio a la línea de tiempo, ajustando las pausas. El video ya incluye los subtítulos; el SRT sirve si querés rehacerlos o traducirlos.
4. Exportá en MP4 H.264, 1920×1080, 25 cuadros por segundo.

No presentar GPS, rutas automáticas, procesamiento de pagos ni facturación fiscal: no se muestran esas funciones. La entrega y el cobro son registros separados. El acceso a Google Sheets requiere la cuenta autorizada y conexión a Internet.

Los datos del ejemplo se cargaron en la demo personal y se retiraron al finalizar; la plantilla quedó vacía. No se modificaron los datos productivos de Estawol.

## Guion técnico completo

| Tiempo | Escena | Captura | Locución / subtítulo |
|---|---|---|---|
| 00:00:00–00:00:08 | Para qué sirve | `01-resumen-vacio.jpg` | ¿Vendés productos y llevás el stock, los pedidos y las entregas en distintos lugares? |
| 00:00:08–00:00:14 | Para qué sirve | `01-resumen-vacio.jpg` | Esta herramienta reúne la información de tu emprendimiento en una sola pantalla. |
| 00:00:14–00:00:20 | Para qué sirve | `01-resumen-vacio.jpg` | Vamos a seguir un ejemplo completo, desde el producto hasta la entrega y el cobro. |
| 00:00:20–00:00:28 | Abrir y verificar la conexión | `04-conexion-sheets.jpg` | Abrí el enlace del sistema con tu cuenta autorizada de Google. No necesitás editar el HTML. |
| 00:00:28–00:00:35 | Abrir y verificar la conexión | `04-conexion-sheets.jpg` | En Conexión con Google Sheets podés comprobar en qué planilla se leen y guardan los registros. |
| 00:00:35–00:00:43 | Registrar un producto | `02-nuevo-producto.jpg` | En Inventario, elegí Nuevo producto. Cargá Termo de acero, código TER-001 y categoría Termos. |
| 00:00:43–00:00:52 | Registrar un producto | `02-nuevo-producto.jpg` | Para este ejemplo usamos un precio de quinientos pesos, veinte unidades iniciales y un mínimo de cinco. |
| 00:00:52–00:01:00 | Registrar un producto | `03-stock-inicial.jpg` | Al crear el producto, aparecen veinte unidades en depósito y veinte disponibles. Todavía no hay reservas ni repartos. |
| 00:01:00–00:01:09 | Nuevo cliente y pedido | `05c-alta-cliente.jpg` | Entrá a Pedidos, tocá Nuevo pedido y elegí Nuevo cliente. Completá nombre, teléfono y dirección de entrega. |
| 00:01:09–00:01:17 | Nuevo cliente y pedido | `05-cliente-y-pedido.jpg` | Ana pide dos termos de quinientos pesos. El total es mil pesos y el cobro inicial queda en cero. |
| 00:01:17–00:01:23 | Nuevo cliente y pedido | `05b-guardar-cliente-y-pedido.jpg` | Al guardar, el cliente queda registrado para futuras compras y el pedido reserva dos unidades. |
| 00:01:23–00:01:30 | Nuevo cliente y pedido | `07-stock-reservado.jpg` | Seguís con veinte en depósito, pero dos están reservadas. Te quedan dieciocho disponibles para vender. |
| 00:01:30–00:01:37 | Preparar, asignar transporte y despachar | `09-listo-para-repartir.jpg` | Desde el pedido, elegí Preparar pedido y después Marcar listo. Ya puede pasar al reparto. |
| 00:01:37–00:01:46 | Preparar, asignar transporte y despachar | `10-datos-transporte.jpg` | Al despachar, registrá la empresa transportista, la matrícula y el nombre del conductor. |
| 00:01:46–00:01:53 | Preparar, asignar transporte y despachar | `10-datos-transporte.jpg` | También podés guardar el tipo y número de documento. Acá usamos datos ficticios de demostración. |
| 00:01:53–00:02:00 | Preparar, asignar transporte y despachar | `12-stock-despachado.jpg` | Confirmá el despacho: quedan dieciocho en depósito y dos en reparto, con el transporte identificado. |
| 00:02:00–00:02:07 | Confirmar entrega y registrar cobro | `13-confirmar-entrega.jpg` | Cuando Ana recibe los productos, confirmá la entrega. El cobro se controla por separado. |
| 00:02:07–00:02:14 | Confirmar entrega y registrar cobro | `14-entregado-sin-cobrar.jpg` | El pedido ya figura entregado, pero todavía tiene mil pesos pendientes de cobro. |
| 00:02:14–00:02:20 | Confirmar entrega y registrar cobro | `15-registrar-cobro.jpg` | Si recibiste el dinero, elegí Registrar cobro y cargá los mil pesos. |
| 00:02:20–00:02:25 | Confirmar entrega y registrar cobro | `16-pedido-cobrado.jpg` | El saldo queda en cero y la entrega conserva su historial. |
| 00:02:25–00:02:31 | Incidencia y retorno físico | `19-entrega-fallida.jpg` | Bruno tiene otro pedido: tres termos por mil quinientos pesos. El cliente está ausente. |
| 00:02:31–00:02:37 | Incidencia y retorno físico | `18-registrar-incidencia.jpg` | Registrá la incidencia. Esos tres termos siguen en reparto; todavía no vuelven al stock. |
| 00:02:37–00:02:41 | Incidencia y retorno físico | `20-confirmar-retorno.jpg` | Cuando los recibís físicamente, confirmá el retorno de los tres termos. |
| 00:02:41–00:02:45 | Incidencia y retorno físico | `21-stock-final.jpg` | Ahora el depósito vuelve a tener dieciocho unidades disponibles. |
| 00:02:45–00:02:53 | Reportes y cierre | `22-reportes.jpg` | En Reportes ves una entrega por mil pesos, mil cobrados y saldo cero. |
| 00:02:53–00:03:00 | Reportes y cierre | `23-resumen-final.jpg` | Así podés controlar existencias, clientes, pedidos y repartos, con registros guardados en Google Sheets. |
