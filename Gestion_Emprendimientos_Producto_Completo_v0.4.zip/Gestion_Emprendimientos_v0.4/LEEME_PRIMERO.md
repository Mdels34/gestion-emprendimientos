# Gestión para emprendimientos | Entrega completa 0.4

Preparado por Martín de los Santos para Fabián. 22/11/2026, America/Montevideo.

1. Presentacion: PDF de 12 páginas para conversar sobre el producto.
2. Demo: HTML autónomo, abrir en el navegador para probar con datos ficticios.
3. Plantilla: estructura vacía; convertir a Google Sheets e instalar el conector para guardar en Drive.
4. Instalador_Google: código y guía de Apps Script.
5. Codigo_fuente: proyecto reproducible, pruebas y documentación.
6. Repositorio_Git: copia Git transportable, con instrucciones para clonarla y publicarla.
7. Tutorial: vídeo sin voz, subtítulos, texto de locución y guion.

No hace falta instalar Git para consultar el PDF, la demo o el código. El tutorial no es necesario para ejecutar la app.

La demo HTML guarda en ese navegador. La instalación Google requiere su propia cuenta, planilla y permisos. Los enlaces precargados llevan a una prueba privada del propietario; entregar archivos no concede acceso.

El repositorio Git está incluido como archivo bundle. No está publicado en un repositorio nuevo de GitHub ni se envió invitación a Fabián. La creación remota requería iniciar sesión.

Marca, precio, primer piloto y condiciones de colaboración pendientes. Alcance, restricciones y verificación están documentados en Codigo_fuente/docs.
